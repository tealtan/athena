var express = require('express'),
    users = require('./routes/users'),
    highlights = require('./routes/highlights');

var app = express();
app.set( "jsonp callback", true )

app.configure(function () {
    app.use(express.logger('dev'));     /* 'default', 'short', 'tiny', 'dev' */
    app.use(express.bodyParser());
});

app.get('/', function(req, res){
  res.send('Gloss server is up.');
});

app.get('/users', users.findAll);
app.get('/users/:id', users.findById);
// TODO: Get user's followers
// TODO: Get user's following

app.get('/highlights', highlights.findAll);
app.get('/highlights/:id', highlights.findById);
// TODO: Find highlights by URL
app.post('/highlights', highlights.addHighlight);
app.put('/highlights/:id', highlights.updateHighlight);
app.delete('/highlights/:id', highlights.deleteHighlight);

app.listen(8000);
console.log('Listening on port 8000');