var mongo = require('mongodb');
 
var Server = mongo.Server,
    Db = mongo.Db,
    BSON = mongo.BSONPure;
 
var server = new Server('localhost', 27017, {auto_reconnect: true});
db = new Db('highlightsdb', server);
 
db.open(function(err, db) {
    if(!err) {
        console.log("Connected to 'highlightsdb' database");
        db.collection('highlights', {strict:true}, function(err, collection) {
            if (err) {
                console.log("The 'highlights' collection doesn't exist. Creating it with sample data...");
                populateHighlightsDB();
            }
        });
    }
});
 
exports.findById = function(req, res) {
    var id = req.params.id;
    console.log('Retrieving highlight: ' + id);
    db.collection('highlights', function(err, collection) {
        collection.findOne({'_id':new BSON.ObjectID(id)}, function(err, item) {
            res.send(item);
        });
    });
};
 
exports.findAll = function(req, res) {
    db.collection('highlights', function(err, collection) {
        collection.find().toArray(function(err, items) {
            res.send(items);
        });
    });
};
 
exports.addHighlight = function(req, res) {
    var highlight = req.body;
    console.log('Adding highlight: ' + JSON.stringify(highlight));
    db.collection('highlights', function(err, collection) {
        collection.insert(highlight, {safe:true}, function(err, result) {
            if (err) {
                res.send({'error':'An error has occurred'});
            } else {
                console.log('Success: ' + JSON.stringify(result[0]));
                res.send(result[0]);
            }
        });
    });
}
 
exports.updateHighlight = function(req, res) {
    var id = req.params.id;
    var highlight = req.body;
    console.log('Updating highlight: ' + id);
    console.log(JSON.stringify(highlight));
    db.collection('highlights', function(err, collection) {
        collection.update({'_id':new BSON.ObjectID(id)}, highlight, {safe:true}, function(err, result) {
            if (err) {
                console.log('Error updating highlight: ' + err);
                res.send({'error':'An error has occurred'});
            } else {
                console.log('' + result + ' document(s) updated');
                res.send(highlight);
            }
        });
    });
}
 
exports.deleteHighlight = function(req, res) {
    var id = req.params.id;
    console.log('Deleting highlight: ' + id);
    db.collection('highlights', function(err, collection) {
        collection.remove({'_id':new BSON.ObjectID(id)}, {safe:true}, function(err, result) {
            if (err) {
                res.send({'error':'An error has occurred - ' + err});
            } else {
                console.log('' + result + ' document(s) deleted');
                res.send(req.body);
            }
        });
    });
}
 
//-------------------------
// Populate database with sample data -- Only used once: the first time the application is started.
// You'd typically not find this code in a real-life app, since the database would already exist.
//-------------------------

var populateHighlightsDB = function() {
 
    var highlights = [
    {
      title: "Judge Orders Morning-After Pill Available for All Ages", 
      url: "http://www.nytimes.com/2013/04/06/health/judge-orders-fda-to-make-morning-after-pill-available-over-the-counter-for-all-ages.html",
      text: "A federal judge ruled Friday that the government must make the most common morning-after pill available over the counter for all ages, instead of requiring a prescription for girls 16 and younger."
    },
    {
      title: "Judge Orders Morning-After Pill Available for All Ages", 
      url: "http://www.nytimes.com/2013/04/06/health/judge-orders-fda-to-make-morning-after-pill-available-over-the-counter-for-all-ages.html",
      text: "The decision, on a fraught and politically controversial subject, comes after a decade-long fight over who should have access to the pill and under what circumstances."
    },
    {
      title: "Obama Budget to Include Cuts to Programs in Hopes of Deal", 
      url: "http://www.nytimes.com/2013/04/05/us/social-programs-face-cutback-in-obama-budget.html",
      text: "In a significant shift in fiscal strategy, Mr. Obama on Wednesday will send a budget plan to Capitol Hill that departs from the usual presidential wish list that Republicans typically declare dead on arrival."
    }];
 
    db.collection('highlights', function(err, collection) {
        collection.insert(highlights, {safe:true}, function(err, result) {});
    });
 
};