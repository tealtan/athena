exports.findAll = function(req, res) {
  res.send([{name:"tealtan", id:"1"}, {name:"altanjohn", id:"2"}]);
};

exports.findById = function(req, res) {
  res.send({id:req.params.id, name: "tealtan", description: "Designer by day, editor by night.", twitter: "@tealtan"});
};